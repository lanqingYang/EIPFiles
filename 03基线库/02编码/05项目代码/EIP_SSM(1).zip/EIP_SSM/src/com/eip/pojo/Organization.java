package com.eip.pojo;

public class Organization {
}
